modernflatdark
==============

Openbox + Gtk2 dark theme.
This theme based on Modern and FlatStudioLight theme
